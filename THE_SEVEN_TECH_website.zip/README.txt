THE SEVEN TECH website
Files: index.html, style.css, script.js

To publish free: upload these files to a GitHub repository and enable GitHub Pages, or deploy the folder through a free hosting service such as Netlify.
The site is responsive and includes WhatsApp contact 8876362.
